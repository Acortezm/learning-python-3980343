# LinkedIn Learning Python course by Joe Marini
# Example file for HelloWorld
print("hello world")
name = input("what's your name: ")
print("hello", name)