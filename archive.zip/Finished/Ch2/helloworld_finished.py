# LinkedIn Learning Python course by Joe Marini
# Example file for HelloWorld


print("hello world!")
name = input("What is your name? ")
print("Nice to meet you,", name)
